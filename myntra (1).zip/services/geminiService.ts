import { GoogleGenAI } from "@google/genai";
import { PRODUCTS } from '../constants';

// Initialize the Gemini client
// Note: In a production app, you should proxy this through a backend to hide the key,
// but for this client-side demo, we use the env var directly.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getStylistResponse = async (userMessage: string, chatHistory: string[] = []) => {
  try {
    const model = 'gemini-2.5-flash';
    
    // Create a context string with our product catalog so the AI knows what we sell
    const productCatalog = PRODUCTS.map(p => 
      `ID: ${p.id}, Name: ${p.title}, Brand: ${p.brand}, Category: ${p.category}, Price: ${p.price}`
    ).join('\n');

    const systemInstruction = `
      You are "Mynther AI", a sophisticated and helpful fashion stylist assistant for the e-commerce store Mynther.
      
      Your goal is to help users find products from our catalog based on their needs (occasions, weather, style preferences).
      
      Here is our current Product Catalog:
      ${productCatalog}
      
      Rules:
      1. Be polite, trendy, and concise.
      2. When you recommend a product, explicitly mention its exact Name and ID from the catalog.
      3. If the user asks about something we don't sell (like electronics), politely steer them back to fashion.
      4. Use emojis sparingly to keep it fun but professional.
      5. Format your response nicely.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: [
        { role: 'user', parts: [{ text: `Context: Previous chat: ${chatHistory.join('\n')} \n Current User Query: ${userMessage}` }] }
      ],
      config: {
        systemInstruction,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having a little trouble connecting to the fashion mainframe right now. Please try again in a moment!";
  }
};
