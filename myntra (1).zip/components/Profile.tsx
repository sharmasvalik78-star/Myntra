import React, { useState } from 'react';
import { User, Package, Heart, MapPin, CreditCard, LogOut, ChevronRight } from 'lucide-react';

interface ProfileProps {
  isLoggedIn: boolean;
  userProfile: any;
  onLogin: (mobile: string) => void;
  onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ isLoggedIn, userProfile, onLogin, onLogout }) => {
  const [mobileNumber, setMobileNumber] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mobileNumber.length < 10) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }
    onLogin(mobileNumber);
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center bg-pink-50 px-4">
        <div className="bg-white w-full max-w-md rounded-lg shadow-lg overflow-hidden">
          {/* Login Banner */}
          <div className="h-32 bg-pink-100 relative">
            <img 
                src="https://constant.myntassets.com/pwa/assets/img/banner_login_landing_300.jpg" 
                onError={(e) => e.currentTarget.src = 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=80'}
                alt="Login Banner" 
                className="w-full h-full object-cover opacity-90"
            />
          </div>
          
          <div className="p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-1">Login <span className="text-sm font-normal text-gray-500">or</span> Signup</h2>
            
            <form onSubmit={handleSubmit} className="mt-6">
              <div className="relative">
                <span className="absolute left-3 top-3 text-gray-500 font-medium">+91 |</span>
                <input
                  type="tel"
                  placeholder="Mobile Number"
                  className="w-full border border-gray-300 rounded px-3 py-3 pl-14 focus:outline-none focus:border-primary font-medium text-gray-900"
                  value={mobileNumber}
                  onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '');
                      setMobileNumber(val);
                      setError('');
                  }}
                  maxLength={10}
                />
              </div>
              <p className="text-xs text-gray-400 mt-2 italic">(For Demo: Enter any 10 digit number to login/signup)</p>
              {error && <p className="text-red-500 text-xs mt-1">{error}</p>}

              <p className="text-xs text-gray-500 mt-4 leading-relaxed">
                By continuing, I agree to the <span className="text-primary font-bold cursor-pointer">Terms of Use</span> & <span className="text-primary font-bold cursor-pointer">Privacy Policy</span>
              </p>

              <button 
                type="submit"
                className="w-full bg-primary text-white font-bold py-3 rounded mt-6 uppercase tracking-wider hover:bg-pink-600 transition-colors"
              >
                Continue
              </button>

              <p className="text-xs text-gray-400 mt-4">
                Have trouble logging in? <span className="text-primary font-bold cursor-pointer">Get Help</span>
              </p>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Account</h1>
          <p className="text-sm text-gray-500">Manage your profile and preferences</p>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="w-full md:w-1/3">
           {/* Profile Card */}
           <div className="bg-white p-4 border border-gray-200 rounded-lg flex items-center gap-4 mb-4">
              <div className="bg-gray-100 p-4 rounded-full">
                  <User size={32} className="text-gray-500" />
              </div>
              <div className="flex-1 overflow-hidden">
                  <p className="text-xs text-gray-500">Hello,</p>
                  <h3 className="font-bold text-gray-900 truncate">{userProfile.name || 'Mynther User'}</h3>
              </div>
           </div>

           {/* Menu */}
           <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer flex items-center justify-between group">
                  <div className="flex items-center gap-3 text-gray-700 font-medium">
                      <Package size={18} className="text-primary" /> Orders
                  </div>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-primary" />
              </div>
              <div className="p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer flex items-center justify-between group">
                  <div className="flex items-center gap-3 text-gray-700 font-medium">
                      <Heart size={18} className="text-primary" /> Wishlist
                  </div>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-primary" />
              </div>
              <div className="p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer flex items-center justify-between group">
                  <div className="flex items-center gap-3 text-gray-700 font-medium">
                      <MapPin size={18} className="text-primary" /> Addresses
                  </div>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-primary" />
              </div>
              <div className="p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer flex items-center justify-between group">
                  <div className="flex items-center gap-3 text-gray-700 font-medium">
                      <CreditCard size={18} className="text-primary" /> Saved Cards
                  </div>
                  <ChevronRight size={16} className="text-gray-400 group-hover:text-primary" />
              </div>
              <div onClick={onLogout} className="p-4 hover:bg-gray-50 cursor-pointer flex items-center justify-between group text-red-500">
                  <div className="flex items-center gap-3 font-medium">
                      <LogOut size={18} /> Logout
                  </div>
              </div>
           </div>
        </div>

        {/* Main Content Area (Mock Overview) */}
        <div className="flex-1">
            <div className="bg-white border border-gray-200 rounded-lg p-6 mb-6">
                <h3 className="font-bold text-lg mb-4">Recent Orders</h3>
                <div className="flex gap-4 p-4 bg-gray-50 rounded border border-gray-100">
                    <div className="h-20 w-16 bg-gray-200 rounded overflow-hidden">
                         <img src="https://images.unsplash.com/photo-1598033129133-e170f6f5f929?auto=format&fit=crop&w=800&q=80" className="w-full h-full object-cover" alt="Order"/>
                    </div>
                    <div className="flex-1">
                        <p className="font-bold text-sm text-gray-900">Premium Cotton Slim Fit Shirt</p>
                        <p className="text-xs text-gray-500 mt-1">Delivered on Jan 15, 2024</p>
                        <span className="text-xs font-bold text-green-600 mt-2 block">● Delivered</span>
                    </div>
                </div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="font-bold text-lg mb-4">Edit Profile</h3>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-xs text-gray-500 mb-1 block">Mobile Number</label>
                        <div className="p-3 bg-gray-50 border border-gray-200 rounded text-gray-700">{userProfile.mobile}</div>
                    </div>
                    <div>
                        <label className="text-xs text-gray-500 mb-1 block">Full Name</label>
                        <input className="w-full p-3 border border-gray-300 rounded focus:border-primary outline-none" defaultValue={userProfile.name} />
                    </div>
                    <div>
                        <label className="text-xs text-gray-500 mb-1 block">Email</label>
                        <input className="w-full p-3 border border-gray-300 rounded focus:border-primary outline-none" defaultValue="user@mynther.com" />
                    </div>
                     <div>
                        <label className="text-xs text-gray-500 mb-1 block">Gender</label>
                        <select className="w-full p-3 border border-gray-300 rounded focus:border-primary outline-none bg-white">
                            <option>Male</option>
                            <option>Female</option>
                        </select>
                    </div>
                </div>
                <button className="mt-6 bg-primary text-white px-6 py-3 rounded font-bold text-sm hover:bg-pink-600">SAVE DETAILS</button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;