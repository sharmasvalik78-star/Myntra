import React, { useState } from 'react';
import { CartItem } from '../types';
import { ShieldCheck, MapPin, CreditCard, Banknote, Truck, CheckCircle } from 'lucide-react';

interface CheckoutProps {
  cartItems: CartItem[];
  totalAmount: number;
  onPlaceOrder: () => void;
}

const Checkout: React.FC<CheckoutProps> = ({ cartItems, totalAmount, onPlaceOrder }) => {
  const [step, setStep] = useState<'ADDRESS' | 'PAYMENT' | 'SUCCESS'>('ADDRESS');
  const [selectedPayment, setSelectedPayment] = useState<string>('cod');
  const [isLoading, setIsLoading] = useState(false);

  // Mock Address Data
  const [address, setAddress] = useState({
    name: '',
    mobile: '',
    pincode: '',
    locality: '',
    city: '',
    state: ''
  });

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('PAYMENT');
  };

  const handlePayment = () => {
    setIsLoading(true);
    // Simulate payment processing
    setTimeout(() => {
      setIsLoading(false);
      setStep('SUCCESS');
      // Clear cart after 2 seconds of success message to let user see it, handled by parent if needed
      setTimeout(() => {
          onPlaceOrder();
      }, 2000);
    }, 1500);
  };

  const originalTotal = cartItems.reduce((acc, item) => acc + item.originalPrice, 0);
  const discount = originalTotal - totalAmount;
  const convenienceFee = 99;
  const finalAmount = totalAmount + convenienceFee;

  if (step === 'SUCCESS') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="mb-6 flex justify-center">
          <div className="bg-green-100 p-4 rounded-full">
            <CheckCircle size={64} className="text-green-500" />
          </div>
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Order Placed Successfully!</h2>
        <p className="text-gray-500 mb-8">Thank you for shopping with Mynther. Your order will be delivered shortly.</p>
        <div className="animate-pulse text-primary font-medium">Redirecting to home...</div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left Section: Forms */}
        <div className="flex-1">
          <div className="border-b border-gray-200 pb-4 mb-6">
            <h2 className="text-xl font-bold text-gray-900 uppercase tracking-wider">
               {step === 'ADDRESS' ? 'Select Delivery Address' : 'Choose Payment Mode'}
            </h2>
          </div>

          {step === 'ADDRESS' && (
            <form onSubmit={handleAddressSubmit} className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
              <h3 className="font-bold text-sm mb-4 uppercase text-gray-700">Contact Details</h3>
              <div className="grid grid-cols-1 gap-4 mb-6">
                <input 
                    required 
                    placeholder="Name*" 
                    className="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-primary"
                    value={address.name}
                    onChange={e => setAddress({...address, name: e.target.value})}
                />
                <input 
                    required 
                    placeholder="Mobile No*" 
                    className="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-primary"
                    value={address.mobile}
                    onChange={e => setAddress({...address, mobile: e.target.value})}
                />
              </div>

              <h3 className="font-bold text-sm mb-4 uppercase text-gray-700">Address</h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <input 
                    required 
                    placeholder="Pincode*" 
                    className="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-primary"
                    value={address.pincode}
                    onChange={e => setAddress({...address, pincode: e.target.value})}
                />
                 <input 
                    required 
                    placeholder="State*" 
                    className="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-primary"
                    value={address.state}
                    onChange={e => setAddress({...address, state: e.target.value})}
                />
              </div>
              <input 
                  required 
                  placeholder="Address (House No, Building, Street Area)*" 
                  className="w-full border border-gray-300 p-3 rounded mb-4 focus:outline-none focus:border-primary"
                  value={address.locality}
                  onChange={e => setAddress({...address, locality: e.target.value})}
              />
               <input 
                  required 
                  placeholder="City / District*" 
                  className="w-full border border-gray-300 p-3 rounded mb-6 focus:outline-none focus:border-primary"
                  value={address.city}
                  onChange={e => setAddress({...address, city: e.target.value})}
              />
              
              <button type="submit" className="w-full bg-primary text-white font-bold py-3 rounded hover:bg-pink-600 transition-colors">
                ADD ADDRESS
              </button>
            </form>
          )}

          {step === 'PAYMENT' && (
             <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <div className="flex">
                    {/* Payment Sidebar */}
                    <div className="w-1/3 bg-gray-50 border-r border-gray-200">
                        {['Recommended', 'Cash On Delivery', 'UPI', 'Cards'].map((mode) => (
                            <div key={mode} className="p-4 border-b border-gray-100 cursor-pointer hover:bg-white font-bold text-gray-600 text-sm">
                                {mode}
                            </div>
                        ))}
                    </div>
                    {/* Payment Options */}
                    <div className="flex-1 p-6">
                        <h3 className="font-bold text-gray-900 mb-4">Recommended Payment Options</h3>
                        
                        <div 
                            onClick={() => setSelectedPayment('cod')}
                            className={`flex items-center p-4 border rounded mb-4 cursor-pointer ${selectedPayment === 'cod' ? 'border-primary bg-pink-50' : 'border-gray-200'}`}
                        >
                             <div className="mr-3 text-primary"><Banknote /></div>
                             <div className="flex-1">
                                 <div className="font-bold text-gray-800">Cash on Delivery (Cash/UPI)</div>
                                 <div className="text-xs text-gray-500">Pay valid amount on delivery</div>
                             </div>
                             <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedPayment === 'cod' ? 'border-primary' : 'border-gray-400'}`}>
                                 {selectedPayment === 'cod' && <div className="w-2 h-2 bg-primary rounded-full"></div>}
                             </div>
                        </div>

                        <div 
                             onClick={() => setSelectedPayment('card')}
                            className={`flex items-center p-4 border rounded mb-4 cursor-pointer ${selectedPayment === 'card' ? 'border-primary bg-pink-50' : 'border-gray-200'}`}
                        >
                             <div className="mr-3 text-primary"><CreditCard /></div>
                             <div className="flex-1">
                                 <div className="font-bold text-gray-800">Credit / Debit Card</div>
                                 <div className="text-xs text-gray-500">Visa, Mastercard, Rupay & more</div>
                             </div>
                             <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedPayment === 'card' ? 'border-primary' : 'border-gray-400'}`}>
                                 {selectedPayment === 'card' && <div className="w-2 h-2 bg-primary rounded-full"></div>}
                             </div>
                        </div>

                        <button 
                            onClick={handlePayment}
                            disabled={isLoading}
                            className="w-full bg-primary text-white font-bold py-3 rounded hover:bg-pink-600 transition-colors disabled:opacity-50 flex items-center justify-center"
                        >
                            {isLoading ? 'PROCESSING...' : `PAY ₹${finalAmount}`}
                        </button>
                    </div>
                </div>
             </div>
          )}
        </div>

        {/* Right Section: Price Details */}
        <div className="w-full lg:w-80">
          <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm sticky top-24">
             <h3 className="text-xs font-bold text-gray-500 uppercase mb-4">Price Details ({cartItems.length} Items)</h3>
             
             <div className="space-y-3 text-sm mb-4 border-b border-gray-100 pb-4">
                <div className="flex justify-between">
                    <span className="text-gray-700">Total MRP</span>
                    <span className="text-gray-900">₹{originalTotal}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-gray-700">Discount on MRP</span>
                    <span className="text-green-500">-₹{discount}</span>
                </div>
                 <div className="flex justify-between">
                    <span className="text-gray-700">Convenience Fee</span>
                    <span className="text-gray-900">₹{convenienceFee}</span>
                </div>
             </div>
             
             <div className="flex justify-between font-bold text-gray-900 text-base mb-6">
                 <span>Total Amount</span>
                 <span>₹{finalAmount}</span>
             </div>

             <div className="flex items-center gap-2 mb-2">
                <ShieldCheck className="text-gray-400" size={32} />
                <p className="text-xs text-gray-500 font-medium">Safe and Secure Payments. Easy returns. 100% Authentic products.</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;