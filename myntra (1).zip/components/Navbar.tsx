import React, { useState } from 'react';
import { ShoppingBag, Search, User, Menu, Heart, X, ChevronRight } from 'lucide-react';
import { Page } from '../types';

interface NavbarProps {
  cartCount: number;
  onNavigate: (page: Page) => void;
  onOpenCart: () => void;
  onCategoryClick: (category: string) => void;
  activeCategory: string;
  onSearch: (query: string) => void;
  searchTerm: string;
}

const Navbar: React.FC<NavbarProps> = ({ 
  cartCount, 
  onNavigate, 
  onOpenCart, 
  onCategoryClick, 
  activeCategory,
  onSearch,
  searchTerm
}) => {
  const navLinks = ['Men', 'Women', 'Kids', 'Footwear', 'Home & Living', 'Beauty', 'Accessories'];
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleNavClick = (cat: string) => {
    onCategoryClick(cat);
    onNavigate(Page.HOME);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-40 bg-white shadow-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Left: Logo & Mobile Menu */}
          <div className="flex items-center h-full">
            <button 
                className="p-2 -ml-2 mr-2 lg:hidden text-gray-600"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <div 
              onClick={() => {
                onNavigate(Page.HOME);
                onCategoryClick('All');
                onSearch('');
              }}
              className="flex-shrink-0 cursor-pointer flex items-center gap-2 mr-8"
            >
              <span className="text-2xl font-bold tracking-tighter text-gray-900">
                Mynther<span className="text-primary">.</span>
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden lg:flex h-full space-x-4">
              {navLinks.map((link) => (
                <button
                  key={link}
                  onClick={() => handleNavClick(link)}
                  className={`
                    flex items-center h-full px-1 text-xs font-bold uppercase tracking-wider border-b-4 transition-colors
                    ${activeCategory === link 
                      ? 'border-primary text-gray-900' 
                      : 'border-transparent text-gray-700 hover:text-gray-900 hover:border-gray-200'}
                  `}
                >
                  {link}
                </button>
              ))}
            </div>
          </div>

          {/* Center: Search (Hidden on small mobile) */}
          <div className="hidden md:flex flex-1 max-w-lg mx-8">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                className="block w-full pl-10 pr-3 py-2 border border-gray-100 bg-gray-50 rounded text-gray-900 placeholder-gray-400 focus:outline-none focus:bg-white focus:border-gray-300 focus:ring-0 sm:text-sm transition duration-150 ease-in-out"
                placeholder="Search for products, brands and more"
                type="search"
                value={searchTerm}
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-4 lg:gap-6">
            <div 
                onClick={() => onNavigate(Page.PROFILE)}
                className="flex flex-col items-center cursor-pointer text-gray-700 hover:text-gray-900 group"
            >
               <User size={18} className="group-hover:scale-105 transition-transform" />
               <span className="text-[11px] font-bold mt-0.5 hidden md:block">Profile</span>
            </div>
             <div className="flex flex-col items-center cursor-pointer text-gray-700 hover:text-gray-900 group">
               <Heart size={18} className="group-hover:scale-105 transition-transform" />
               <span className="text-[11px] font-bold mt-0.5 hidden md:block">Wishlist</span>
            </div>
            <div 
              className="flex flex-col items-center cursor-pointer text-gray-700 hover:text-gray-900 relative group"
              onClick={onOpenCart}
            >
               <ShoppingBag size={18} className="group-hover:scale-105 transition-transform" />
               <span className="text-[11px] font-bold mt-0.5 hidden md:block">Bag</span>
               {cartCount > 0 && (
                 <span className="absolute -top-1 right-0 md:right-1 bg-primary text-white text-[10px] font-bold rounded-full h-4 w-4 flex items-center justify-center">
                   {cartCount}
                 </span>
               )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="absolute top-20 left-0 w-full bg-white shadow-lg z-50 lg:hidden border-t border-gray-100">
            <div className="p-4">
                <div className="mb-4 md:hidden">
                    <div className="relative w-full">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={18} className="text-gray-400" />
                    </div>
                    <input
                        className="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded text-gray-900 placeholder-gray-400 focus:outline-none focus:border-primary sm:text-sm"
                        placeholder="Search..."
                        type="search"
                        value={searchTerm}
                        onChange={(e) => onSearch(e.target.value)}
                    />
                    </div>
                </div>
                <div className="flex flex-col">
                    {navLinks.map(link => (
                         <button
                            key={link}
                            onClick={() => handleNavClick(link)}
                            className={`text-left py-3 px-2 text-sm font-bold border-b border-gray-50 flex justify-between items-center ${activeCategory === link ? 'text-primary' : 'text-gray-700'}`}
                        >
                            {link}
                            <ChevronRight size={16} className="text-gray-300" />
                        </button>
                    ))}
                </div>
            </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;