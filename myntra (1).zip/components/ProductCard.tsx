import React from 'react';
import { Product } from '../types';
import { Star, Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onClick: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick }) => {
  return (
    <div 
      className="group relative bg-white cursor-pointer overflow-hidden hover:shadow-lg transition-shadow duration-300 border border-transparent hover:border-gray-100"
      onClick={() => onClick(product)}
    >
      {/* Image Container */}
      <div className="aspect-[4/5] w-full overflow-hidden bg-gray-200 relative">
        <img
          src={product.image}
          alt={product.title}
          className="h-full w-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute bottom-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-xs font-bold flex items-center gap-1 shadow-sm">
          <span className="text-gray-900">{product.rating}</span>
          <Star size={10} className="text-teal-500 fill-teal-500" />
          <span className="text-gray-400 font-normal">| {product.reviews}</span>
        </div>
        
        {/* Wishlist Overlay */}
        <button className="absolute top-2 right-2 p-2 rounded-full bg-white/80 text-gray-400 hover:text-primary hover:bg-white transition-colors opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 duration-200">
            <Heart size={18} />
        </button>
      </div>

      {/* Product Info */}
      <div className="p-3">
        <h3 className="text-base font-bold text-gray-900 truncate">{product.brand}</h3>
        <p className="text-sm text-gray-500 truncate mb-1">{product.title}</p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-sm font-bold text-gray-900">₹{product.price}</span>
          <span className="text-xs text-gray-400 line-through">₹{product.originalPrice}</span>
          <span className="text-xs text-orange-500 font-medium">({product.discount}% OFF)</span>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
